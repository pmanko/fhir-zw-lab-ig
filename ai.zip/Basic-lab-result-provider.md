# Resource lab-result-provider



## Resource Content

```json
{
  "resourceType" : "Basic",
  "id" : "lab-result-provider",
  "extension" : [{
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.url",
    "valueUri" : "http://mohcc.gov.zw/fhir/lab/ActorDefinition/lab-result-provider"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.version",
    "valueString" : "0.1.0"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.name",
    "valueString" : "LabResultProvider"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.title",
    "valueString" : "Lab Result Provider"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.status",
    "valueCode" : "draft"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.date",
    "valueDateTime" : "2026-06-12T09:26:59+02:00"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.publisher",
    "valueString" : "MOH Zimbabwe"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.contact",
    "valueContactDetail" : {
      "name" : "MOH Zimbabwe",
      "telecom" : [{
        "system" : "url",
        "value" : "http://mohcc.org.zw"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.description",
    "valueMarkdown" : "System that assembles the signed-off laboratory result as a ZWLabReportBundle document (ZWLabReportComposition, ZWLabDiagnosticReport, ZWLabResultObservation) and pushes it to the Lab Result Repository (FHIR `POST /Bundle` — result push). In the Zimbabwe national architecture this role is played by the Senaite LIMS."
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.jurisdiction",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
        "code" : "716",
        "display" : "Zimbabwe (ZWE)"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.type",
    "valueCode" : "system"
  },
  {
    "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-ActorDefinition.documentation",
    "valueMarkdown" : "Obligations: SHALL submit result documents conforming to the ZWLabReportBundle profile; SHALL include the legal attester sign-off (ZW.LAB.A.DE80/DE82) before submission; SHALL reference the originating ZWLabServiceRequest from the DiagnosticReport."
  }],
  "code" : {
    "coding" : [{
      "system" : "http://hl7.org/fhir/fhir-types",
      "code" : "ActorDefinition"
    }]
  }
}

```
