# Example — Viral Load Order Transaction Bundle - Zimbabwe Laboratory Ordering and Results IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example — Viral Load Order Transaction Bundle**

## Example Bundle: Example — Viral Load Order Transaction Bundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "example-zw-lab-order-bundle",
  "meta" : {
    "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-order-bundle"]
  },
  "type" : "transaction",
  "entry" : [{
    "fullUrl" : "urn:uuid:5a3952e2-1c1a-4a6b-9c5d-0b6e9a3e0001",
    "resource" : {
      "resourceType" : "Task",
      "id" : "example-zw-lab-task-order",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-task"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Task_example-zw-lab-task-order\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Task example-zw-lab-task-order</b></p><a name=\"example-zw-lab-task-order\"> </a><a name=\"hcexample-zw-lab-task-order\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-task.html\">ZW Lab Order Task</a></p></div><p><b>basedOn</b>: <a href=\"ServiceRequest-example-zw-service-request-vl.html\">ServiceRequest Viral Load Plasma</a></p><p><b>status</b>: Requested</p><p><b>intent</b>: order</p><p><b>for</b>: <a href=\"Patient-example-zw-lab-patient.html\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</a></p><p><b>authoredOn</b>: 2024-03-15 08:00:00+0200</p><p><b>location</b>: <a href=\"Location-example-order-facility.html\">Location Harare City Health Clinic</a></p><h3>Restrictions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Recipient</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Organization-example-national-virology-lab.html\">Organization National Virology Laboratory</a></td></tr></table><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type pregnant}\">Pregnant</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type breastfeeding}\">Breastfeeding</span></p><p><b>value</b>: false</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type art-start-date}\">ART Start Date</span></p><p><b>value</b>: 2019-07-01</p></blockquote><blockquote><p><b>input</b></p><p><b>type</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type regimen}\">Regimen</span></p><p><b>value</b>: TDF/3TC/DTG</p></blockquote></div>"
      },
      "basedOn" : [{
        "reference" : "ServiceRequest/example-zw-service-request-vl"
      }],
      "status" : "requested",
      "intent" : "order",
      "for" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "authoredOn" : "2024-03-15T08:00:00+02:00",
      "location" : {
        "reference" : "Location/example-order-facility"
      },
      "restriction" : {
        "recipient" : [{
          "reference" : "Organization/example-national-virology-lab"
        }]
      },
      "input" : [{
        "type" : {
          "coding" : [{
            "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type",
            "code" : "pregnant"
          }]
        },
        "valueBoolean" : false
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type",
            "code" : "breastfeeding"
          }]
        },
        "valueBoolean" : false
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type",
            "code" : "art-start-date"
          }]
        },
        "valueDate" : "2019-07-01"
      },
      {
        "type" : {
          "coding" : [{
            "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-task-input-type",
            "code" : "regimen"
          }]
        },
        "valueString" : "TDF/3TC/DTG"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Task"
    }
  },
  {
    "fullUrl" : "urn:uuid:5a3952e2-1c1a-4a6b-9c5d-0b6e9a3e0002",
    "resource" : {
      "resourceType" : "ServiceRequest",
      "id" : "example-zw-service-request-vl",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-service-request"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"ServiceRequest_example-zw-service-request-vl\"> </a><p class=\"res-header-id\"><b>Generated Narrative: ServiceRequest example-zw-service-request-vl</b></p><a name=\"example-zw-service-request-vl\"> </a><a name=\"hcexample-zw-service-request-vl\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-service-request.html\">ZW Lab Service Request</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Order</p><p><b>code</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests LTT0013}\">Viral Load Plasma</span></p><p><b>subject</b>: <a href=\"Patient-example-zw-lab-patient.html\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</a></p><p><b>authoredOn</b>: 2024-03-15 08:00:00+0200</p><p><b>locationReference</b>: <a href=\"Location-example-order-facility.html\">Location Harare City Health Clinic</a></p><p><b>reasonCode</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-reason-for-test routine}\">Routine</span></p><p><b>specimen</b>: <a href=\"Specimen-example-zw-specimen-plasma.html\">Specimen: identifier = http://mohcc.gov.zw/fhir/lab/identifier/client-sample-id#ZW-SPEC-2024-00456; status = available; type = Blood Plasma</a></p></div>"
      },
      "status" : "active",
      "intent" : "order",
      "code" : {
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-lab-tests",
          "code" : "LTT0013",
          "display" : "Viral Load Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "authoredOn" : "2024-03-15T08:00:00+02:00",
      "locationReference" : [{
        "reference" : "Location/example-order-facility"
      }],
      "reasonCode" : [{
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-reason-for-test",
          "code" : "routine",
          "display" : "Routine"
        }]
      }],
      "specimen" : [{
        "reference" : "Specimen/example-zw-specimen-plasma"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "ServiceRequest"
    }
  },
  {
    "fullUrl" : "urn:uuid:5a3952e2-1c1a-4a6b-9c5d-0b6e9a3e0003",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "example-zw-lab-patient",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-patient"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_example-zw-lab-patient\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient example-zw-lab-patient</b></p><a name=\"example-zw-lab-patient\"> </a><a name=\"hcexample-zw-lab-patient\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-lab-patient.html\">ZW Lab Patient</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Known Marital status of Patient\">Marital Status:</td><td colspan=\"3\"><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-MaritalStatus M}\">Married</span></td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Other Id (see the one above)\">Other Id:</td><td colspan=\"3\"><code>http://mohcc.gov.zw/fhir/lab/identifier/art-number</code>/HRE/2019/005678</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Indicates that the client's date of birth is an estimate rather than the precise birth date. Corresponds to the Impilo→Senaite contract field `dateOfBirthEstimated`.\"><a href=\"StructureDefinition-date-of-birth-estimated.html\">Date of Birth Estimated</a></td><td colspan=\"3\">false</td></tr></table></div>"
      },
      "extension" : [{
        "url" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/date-of-birth-estimated",
        "valueBoolean" : false
      }],
      "identifier" : [{
        "system" : "http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id",
        "value" : "EHR-ZW-00123"
      },
      {
        "system" : "http://mohcc.gov.zw/fhir/lab/identifier/art-number",
        "value" : "HRE/2019/005678"
      }],
      "name" : [{
        "family" : "Moyo",
        "given" : ["Rutendo"]
      }],
      "gender" : "female",
      "birthDate" : "1988-04-15",
      "maritalStatus" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
          "code" : "M",
          "display" : "Married"
        }]
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient",
      "ifNoneExist" : "identifier=http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id|EHR-ZW-00123"
    }
  },
  {
    "fullUrl" : "urn:uuid:5a3952e2-1c1a-4a6b-9c5d-0b6e9a3e0004",
    "resource" : {
      "resourceType" : "Specimen",
      "id" : "example-zw-specimen-plasma",
      "meta" : {
        "profile" : ["http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-specimen"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Specimen_example-zw-specimen-plasma\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Specimen example-zw-specimen-plasma</b></p><a name=\"example-zw-specimen-plasma\"> </a><a name=\"hcexample-zw-specimen-plasma\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-zw-specimen.html\">ZW Lab Specimen</a></p></div><p><b>identifier</b>: <code>http://mohcc.gov.zw/fhir/lab/identifier/client-sample-id</code>/ZW-SPEC-2024-00456</p><p><b>status</b>: Available</p><p><b>type</b>: <span title=\"Codes:{http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-sample-types LST006}\">Blood Plasma</span></p><p><b>subject</b>: <a href=\"Patient-example-zw-lab-patient.html\">Rutendo Moyo  Female, DoB: 1988-04-15 ( http://mohcc.gov.zw/fhir/lab/identifier/ehr-patient-id#EHR-ZW-00123)</a></p><h3>Collections</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Collected[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>2024-03-15 08:30:00+0200</td></tr></table></div>"
      },
      "identifier" : [{
        "system" : "http://mohcc.gov.zw/fhir/lab/identifier/client-sample-id",
        "value" : "ZW-SPEC-2024-00456"
      }],
      "status" : "available",
      "type" : {
        "coding" : [{
          "system" : "http://mohcc.gov.zw/fhir/lab/CodeSystem/zw-sample-types",
          "code" : "LST006",
          "display" : "Blood Plasma"
        }]
      },
      "subject" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "collection" : {
        "collectedDateTime" : "2024-03-15T08:30:00+02:00"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "Specimen"
    }
  }]
}

```
