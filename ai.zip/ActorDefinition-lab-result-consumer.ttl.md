# Lab Result Consumer - TTL Representation - Zimbabwe Laboratory Ordering and Results IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Lab Result Consumer**

## : Lab Result Consumer - TTL Representation

| |
| :--- |
| Draft as of 2026-06-12 |

[Raw ttl](ActorDefinition-lab-result-consumer.ttl) | [Download](ActorDefinition-lab-result-consumer.ttl)

