# Home - Zimbabwe Laboratory Ordering and Results IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://mohcc.gov.zw/fhir/lab/ImplementationGuide/zw.fhir.ig.lab | *Version*:0.1.0 |
| Draft as of 2026-06-12 | *Computable Name*:ZWCore |

This implementation guide and set of artifacts are still undergoing development.

Content is for demonstration and practice purposes only.

### Summary

This Implementation Guide (IG) defines FHIR R4 profiles, logical models, and terminology for **laboratory test ordering and result reporting in Zimbabwe**. It supports the national digital health architecture connecting:

* **Impilo EHR** — the ordering electronic health record system used at health facilities
* **OpenHIM** — the Health Information Exchange (HIE) interoperability layer (routing, validation, audit)
* **Shared Health Record (SHR)** — the HAPI FHIR server storing all orders and results
* **Senaite LIMS** — the national Laboratory Information Management System

### Transaction Flow

The exchange uses a **push-and-pull** model:

1. **Order submission (push):**Impilo submits a`Task`+`ServiceRequest`+`Specimen`to OpenHIM (FHIR`POST`). OpenHIM validates and stores the order in the SHR.
1. **Order retrieval (pull):**Senaite LIMS periodically queries the SHR (`FHIR Search`) to retrieve orders assigned to it.
1. **Result submission (push):**After testing, Senaite pushes a`DiagnosticReport`+`Observation`to OpenHIM, which stores the result in the SHR.
1. **Result retrieval (pull):**Impilo queries the SHR to retrieve results for its patients.

Patient identity is resolved via **VITO (MPI/Client Registry)** and terminology is validated via **Butano** (SNOMED CT, LOINC, ICD-10).

### Scope — Iteration 1

This first iteration includes:

* **Logical models:** `ZWLabOrder` (ZW.LAB.A1) and `ZWLabResultReport` (ZW.LAB.A2) derived from the Zimbabwe Lab DAK data dictionary.
* **Profiles:** `ZWLabPatient`, `ZWLabTask`, `ZWLabServiceRequest`, `ZWSpecimen`, `ZWLaboratory`, `ZWFacility`, `ZWLabDiagnosticReport`, `ZWLabResultObservation`.
* **Exchange bundles:** `ZWLabOrderBundle` (order transaction) and `ZWLabReportBundle` (signed-off result report document with `ZWLabReportComposition`).
* **Actors and requirements:** the six [workflow actors](actors.md) (Lab Order Placer/Repository/Fulfiller, Lab Result Provider/Repository/Consumer) and per-transaction Requirements.
* **Extensions:** `DateOfBirthEstimated`, `ReportReviewState`.
* **Terminology:** National code systems and value sets for tests, sample types, reasons for test, rejection reasons, report review states, and the national laboratory list.
* **Examples:** End-to-end Viral Load Plasma order and result scenario.
* **Testing:** a Gherkin/Karate [actor conformance test kit](testing.md) exercising the workflow transactions.

### Out of Scope (Iteration 1)

CapabilityStatements, ConceptMaps, Questionnaires, decision-support logic, indicator measures, ICD-11/LOINC/SNOMED terminologist mappings.

### Relationship to Other Guides

This IG targets Zimbabwe national use. It draws on design patterns from the [HL7 Europe Laboratory Report IG](https://build.fhir.org/ig/hl7-eu/laboratory/) for logical model structure and profile conventions.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "zw.fhir.ig.lab",
  "url" : "http://mohcc.gov.zw/fhir/lab/ImplementationGuide/zw.fhir.ig.lab",
  "version" : "0.1.0",
  "name" : "ZWCore",
  "title" : "Zimbabwe Laboratory Ordering and Results IG",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-06-12T09:26:59+02:00",
  "publisher" : "MOH Zimbabwe",
  "contact" : [{
    "name" : "MOH Zimbabwe",
    "telecom" : [{
      "system" : "url",
      "value" : "http://mohcc.org.zw"
    }]
  }],
  "description" : "Zimbabwe Laboratory Ordering and Results FHIR Implementation Guide",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "716",
      "display" : "Zimbabwe (ZWE)"
    }]
  }],
  "packageId" : "zw.fhir.ig.lab",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.1.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "core",
    "uri" : "http://mohcc.gov.zw/fhir/core/ImplementationGuide/zw.fhir.ig.core",
    "packageId" : "zw.fhir.ig.core",
    "version" : "current"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://mohcc.gov.zw/fhir/lab/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2025+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "http://mohcc.gov.zw/fhir/lab/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/date-of-birth-estimated"
      },
      "name" : "Date of Birth Estimated",
      "description" : "Indicates that the client's date of birth is an estimate rather than the precise birth date. Corresponds to the Impilo→Senaite contract field `dateOfBirthEstimated`.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Specimen"
      }],
      "reference" : {
        "reference" : "Specimen/example-zw-specimen-plasma"
      },
      "name" : "Example — Blood Plasma Specimen",
      "description" : "Example blood plasma specimen for the Viral Load Plasma order.",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-specimen"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Task"
      }],
      "reference" : {
        "reference" : "Task/example-zw-lab-task-order"
      },
      "name" : "Example — Lab Order Task",
      "description" : "Task sent by Impilo EHR to the LIMS via OpenHIM representing the lab order (step 1 of the HIE transaction flow).",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-task"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/example-national-virology-lab"
      },
      "name" : "Example — National Virology Laboratory",
      "description" : "Example Organization instance for the National Virology Laboratory (ZWLPAR001).",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-laboratory"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Location"
      }],
      "reference" : {
        "reference" : "Location/example-order-facility"
      },
      "name" : "Example — Ordering Health Facility",
      "description" : "Example Location instance for a primary health facility placing the order.",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-facility"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/example-zw-vl-diagnostic-report"
      },
      "name" : "Example — Viral Load Diagnostic Report",
      "description" : "DiagnosticReport for the Viral Load Plasma result, pushed by the LIMS to the Shared Health Record (step 5 of the HIE transaction flow).",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-diagnostic-report"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/example-zw-lab-order-bundle"
      },
      "name" : "Example — Viral Load Order Transaction Bundle",
      "description" : "Transaction Bundle submitted by the Lab Order Placer (Impilo EHR) to the Lab Order Repository (SHR): order Task, ServiceRequest, Patient and Specimen (step 1 of the HIE transaction flow).",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-order-bundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ServiceRequest"
      }],
      "reference" : {
        "reference" : "ServiceRequest/example-zw-service-request-vl"
      },
      "name" : "Example — Viral Load Plasma Service Request",
      "description" : "Example ServiceRequest for a Viral Load Plasma test (baseline monitoring).",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-service-request"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Bundle"
      }],
      "reference" : {
        "reference" : "Bundle/example-zw-vl-report-bundle"
      },
      "name" : "Example — Viral Load Report Document Bundle",
      "description" : "Signed-off snapshot document of the Viral Load Plasma result, assembled by the LIMS for exchange via OpenHIM/SHR.",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-report-bundle"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Observation"
      }],
      "reference" : {
        "reference" : "Observation/example-zw-vl-observation"
      },
      "name" : "Example — Viral Load Result Observation",
      "description" : "Example HIV Viral Load Plasma result (copies/mL) returned by the LIMS.",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-result-observation"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/example-zw-lab-patient"
      },
      "name" : "Example — ZW Lab Patient",
      "description" : "Example Patient for the Viral Load end-to-end scenario.",
      "exampleCanonical" : "http://mohcc.gov.zw/fhir/lab/StructureDefinition/zw-lab-patient"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      }],
      "reference" : {
        "reference" : "ActorDefinition/lab-order-fulfiller"
      },
      "name" : "Lab Order Fulfiller",
      "description" : "Laboratory system that retrieves orders from the Lab Order Repository and performs the requested testing.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      }],
      "reference" : {
        "reference" : "ActorDefinition/lab-order-placer"
      },
      "name" : "Lab Order Placer",
      "description" : "System that creates laboratory orders and submits them to the Lab Order Repository.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      }],
      "reference" : {
        "reference" : "ActorDefinition/lab-order-repository"
      },
      "name" : "Lab Order Repository",
      "description" : "System that stores submitted laboratory orders and makes them available for retrieval.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      }],
      "reference" : {
        "reference" : "ActorDefinition/lab-result-consumer"
      },
      "name" : "Lab Result Consumer",
      "description" : "System that retrieves laboratory results from the Lab Result Repository for display and clinical use.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      }],
      "reference" : {
        "reference" : "ActorDefinition/lab-result-provider"
      },
      "name" : "Lab Result Provider",
      "description" : "System that produces laboratory results and pushes them to the Lab Result Repository.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ActorDefinition"
      }],
      "reference" : {
        "reference" : "ActorDefinition/lab-result-repository"
      },
      "name" : "Lab Result Repository",
      "description" : "System that stores laboratory result reports and makes them available for retrieval.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      }],
      "reference" : {
        "reference" : "Requirements/zw-lab-order-pull"
      },
      "name" : "Order Pull Requirements",
      "description" : "Requirements for retrieval of laboratory orders by the Lab Order Fulfiller from the Lab Order Repository (transaction ②, pull).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      }],
      "reference" : {
        "reference" : "Requirements/zw-lab-order-push"
      },
      "name" : "Order Push Requirements",
      "description" : "Requirements for submitting a laboratory order from the Lab Order Placer to the Lab Order Repository (transaction ①, push).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/citizenship"
      },
      "name" : "Patient Citizenship",
      "description" : "The patient's legal status as citizen of a country.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      }],
      "reference" : {
        "reference" : "StructureDefinition/report-review-state"
      },
      "name" : "Report Review State",
      "description" : "The LIMS workflow/publication state of a laboratory report (ZW.LAB.A.DE73). This mutable status is separate from the FHIR `DiagnosticReport.status` lifecycle status, which tracks the clinical finality of the report.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      }],
      "reference" : {
        "reference" : "Requirements/zw-lab-result-pull"
      },
      "name" : "Result Pull Requirements",
      "description" : "Requirements for retrieval of laboratory results by the Lab Result Consumer from the Lab Result Repository (result pull).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Requirements"
      }],
      "reference" : {
        "reference" : "Requirements/zw-lab-result-push"
      },
      "name" : "Result Push Requirements",
      "description" : "Requirements for submitting a signed-off laboratory result report from the Lab Result Provider to the Lab Result Repository (result push).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-breastfeeding-status"
      },
      "name" : "ZW Breastfeeding Status",
      "description" : "Whether the client is breastfeeding at the time of the laboratory order (ZW.LAB.A.DE14).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-facility"
      },
      "name" : "ZW Health Facility (Location)",
      "description" : "A health facility placing a laboratory order in Zimbabwe (ZW.LAB.A.DE11).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-diagnostic-report"
      },
      "name" : "ZW Lab Diagnostic Report",
      "description" : "A laboratory result report produced by a Zimbabwe LIMS and pushed to the Shared Health Record (ZW.LAB.A2 DE73–DE99).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-order"
      },
      "name" : "ZW Lab Order (ZW.LAB.A1)",
      "description" : "Logical model for ordering a laboratory test in Zimbabwe. Covers all data elements defined in activity ZW.LAB.A1 of the Zimbabwe Lab DAK data dictionary.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-task"
      },
      "name" : "ZW Lab Order Task",
      "description" : "Task that wraps a laboratory test order sent from Impilo (EHR) to a LIMS via OpenHIM. Carries the ServiceRequest plus contextual clinical information (ZW.LAB.A1).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-order-bundle"
      },
      "name" : "ZW Lab Order Transaction Bundle",
      "description" : "Transaction Bundle used to submit a laboratory order to the Shared Health Record: a ZWLabTask wrapping a ZWLabServiceRequest, together with the ZWLabPatient and any ZWSpecimen resources. Submitted by the Lab Order Placer as a FHIR transaction (step 1 of the HIE transaction flow). Entries may be created with POST or submitted as idempotent client-id updates with PUT.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-patient"
      },
      "name" : "ZW Lab Patient",
      "description" : "Patient demographics exchanged in the Zimbabwe lab ordering workflow (ZW.LAB.A1 DE1–DE9).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-report-composition"
      },
      "name" : "ZW Lab Report Composition",
      "description" : "Composition for a Zimbabwe laboratory result report document. The legal attester records the sign-off of the report by the responsible laboratory authority (ZW.LAB.A.DE80/DE82).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-report-bundle"
      },
      "name" : "ZW Lab Report Document Bundle",
      "description" : "Document Bundle carrying a signed-off snapshot of a Zimbabwe laboratory result report: a ZWLabReportComposition followed by the DiagnosticReport, Observations, Patient, Specimen and supporting resources.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-result-observation"
      },
      "name" : "ZW Lab Result Observation",
      "description" : "A single laboratory test result measured by a Zimbabwe LIMS (ZW.LAB.A2 DE83–DE87).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-result-report"
      },
      "name" : "ZW Lab Result Report (ZW.LAB.A2)",
      "description" : "Logical model for reporting a laboratory result in Zimbabwe. Covers all data elements defined in activity ZW.LAB.A2 of the Zimbabwe Lab DAK data dictionary.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-lab-service-request"
      },
      "name" : "ZW Lab Service Request",
      "description" : "A laboratory test request from a Zimbabwe health facility to a laboratory (ZW.LAB.A1 DE17–DE72).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-specimen"
      },
      "name" : "ZW Lab Specimen",
      "description" : "A laboratory specimen collected in the Zimbabwe lab workflow (ZW.LAB.A1 DE52–DE72).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-task-input-type"
      },
      "name" : "ZW Lab Task Input Type",
      "description" : "Type codes for Task.input slices on the ZWLabTask order profile.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-task-output-type"
      },
      "name" : "ZW Lab Task Output Type",
      "description" : "Type codes for Task.output slices on the ZWLabTask order profile.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-laboratory"
      },
      "name" : "ZW Laboratory (Organization)",
      "description" : "A laboratory in the national Zimbabwe laboratory network. Used as the receiving laboratory for an order (ZW.LAB.A.DE10) and as the reporting organisation for a DiagnosticReport.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/zw-lab-tests"
      },
      "name" : "ZW Laboratory Tests",
      "description" : "Value set of laboratory tests requestable in Zimbabwe (ZW.LAB.A.DE17).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-lab-tests"
      },
      "name" : "ZW Laboratory Tests",
      "description" : "National code list for laboratory tests ordered in Zimbabwe (ZW.LAB.A.DE17).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/zw-laboratories"
      },
      "name" : "ZW National Laboratory List",
      "description" : "Value set of national laboratory identifiers in Zimbabwe.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-laboratories"
      },
      "name" : "ZW National Laboratory List",
      "description" : "National identifiers for public-health laboratories in Zimbabwe.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/zw-pregnancy-status"
      },
      "name" : "ZW Pregnancy Status",
      "description" : "Whether the client is pregnant at the time of the laboratory order (ZW.LAB.A.DE13).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/zw-reason-for-test"
      },
      "name" : "ZW Reason for Test",
      "description" : "Value set of reasons for laboratory test requests in Zimbabwe (ZW.LAB.A.DE30).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-reason-for-test"
      },
      "name" : "ZW Reason for Test",
      "description" : "Coded reasons for laboratory test requests in Zimbabwe (ZW.LAB.A.DE30).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/zw-report-review-state"
      },
      "name" : "ZW Report Review State",
      "description" : "Value set of LIMS workflow states for a laboratory report (ZW.LAB.A.DE73).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-report-review-state"
      },
      "name" : "ZW Report Review State",
      "description" : "LIMS workflow/review state for a laboratory report (ZW.LAB.A.DE73).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/zw-rejection-reasons"
      },
      "name" : "ZW Specimen Rejection Reasons",
      "description" : "Value set of specimen rejection reasons (ZW.LAB.A.DE88).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-rejection-reasons"
      },
      "name" : "ZW Specimen Rejection Reasons",
      "description" : "Reasons a specimen was rejected by the laboratory (ZW.LAB.A.DE88).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/zw-sample-types"
      },
      "name" : "ZW Specimen Types",
      "description" : "Value set of specimen/sample types used in Zimbabwe (ZW.LAB.A.DE53).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/zw-sample-types"
      },
      "name" : "ZW Specimen Types",
      "description" : "National code list for specimen/sample types collected in Zimbabwe (ZW.LAB.A.DE53).",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "actors.html"
        }],
        "nameUrl" : "actors.html",
        "title" : "Actors",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "testing.html"
        }],
        "nameUrl" : "testing.html",
        "title" : "Testing",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "about.html"
        }],
        "nameUrl" : "about.html",
        "title" : "About",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
